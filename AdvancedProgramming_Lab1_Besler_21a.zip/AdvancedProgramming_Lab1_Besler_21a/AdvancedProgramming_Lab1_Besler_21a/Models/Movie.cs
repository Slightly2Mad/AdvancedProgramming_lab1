﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lab1_Besler_21a.Models
{
        public class Movie
        {
        [Display(Name = "Identyfikator")]
            public int Id { get; set; }

        [Display(Name = "Tytuł")]

        [StringLength(30)]
            public string Title { get; set; }

        [Display(Name = "Data premiery")]

        [DataType(DataType.Date)]
            public DateTime ReleaseDate { get; set; }

        [Display(Name = "Gatunek")]
            public string Genre { get; set; }

        [Display(Name = "Cena")]

        [Range(0.01, 100)]
        public decimal Price { get; set; }

    }
    }


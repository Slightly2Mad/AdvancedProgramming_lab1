﻿using AdvancedProgramming_Lab1_Besler_21a.Models;
using Microsoft.EntityFrameworkCore;

namespace AdvancedProgramming_Lab1_Besler_21a.Data
{
    public class MvcMovieContext : DbContext
    {
        public MvcMovieContext(DbContextOptions<MvcMovieContext> options)
            : base(options)
        {
        }

        public DbSet<Movie> Movie { get; set; }
    }
}
